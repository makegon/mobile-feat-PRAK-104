export type PhotoType = {
  uri: string
  type: string
  name: string
}
