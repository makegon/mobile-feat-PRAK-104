export type ToastMessageType = {
  message: string
  type: 'error' | 'popup' | 'green_message' | 'red_message' | ''
}
