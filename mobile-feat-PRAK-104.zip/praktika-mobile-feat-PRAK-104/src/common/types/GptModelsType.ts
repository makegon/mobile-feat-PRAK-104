export type GptModelsType = {
  id: number
  name: string
  is_selected: boolean
}
