export type PromptType = {
  id: number
  icon?: string
  name: string
  description?: string
  prompt: string
  categoryName?: string
}
