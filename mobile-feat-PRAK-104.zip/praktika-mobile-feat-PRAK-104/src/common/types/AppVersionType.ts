export type AppVersionType = {
  version: string
  buildNumber: string
}
