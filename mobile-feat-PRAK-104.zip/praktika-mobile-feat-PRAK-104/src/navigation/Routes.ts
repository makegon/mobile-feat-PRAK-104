export enum Routers {
  HOME = 'Home',
  AUTH = 'Auth',
  REGISTRATION = 'Registration',
  PAYWALL = 'Paywall',
  PROFILE = 'Profile',
  CHAT = 'Chat',
  IMAGE_VIEWER = 'ImageViewer',
  CAMERA = 'Camera',
}
